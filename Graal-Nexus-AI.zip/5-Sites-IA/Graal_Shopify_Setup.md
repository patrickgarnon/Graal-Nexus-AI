# Setup Shopify
Instructions pour connecter boutique Graal Nexus avec Make, Amazon, Stripe.