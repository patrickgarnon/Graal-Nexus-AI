# Guide d'installation
1. Importer ce projet dans GitHub.
2. Importer les fichiers JSON dans Make.
3. Connecter vos API (OpenRouter, ElevenLabs, Stripe, Amazon).
4. Activer l'autopilot total.